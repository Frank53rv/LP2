/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lp3;
import java.util.Scanner;
/**
 *
 * @author cuent
 */
public class LP3 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Definicion de Parametros Predeterminados
            int temperaturaMananaMuyBuena = 10;
            int temperaturaMananaNormalMin = 10;
            int temperaturaMananaNormalMax = 30;
            int temperaturaMananaPeligrosa = 30;

            int temperaturaTardeMuyBuena = 20;
            int temperaturaTardeNormalMin = 20;
            int temperaturaTardeNormalMax = 35;
            int temperaturaTardePeligrosa = 35;

            int temperaturaNocheMuyBuena = 15;
            int temperaturaNocheNormalMin = 15;
            int temperaturaNocheNormalMax = 25;
            int temperaturaNochePeligrosa = 25;

            // Solicitud de Datos al Usuario
            System.out.println("Ingrese el momento del dia (manana, tarde, noche): ");
            String momentoDia = scanner.nextLine().toLowerCase();
            System.out.println("Ingrese la temperatura actual del tanque de combustible: ");
            int temperaturaActual = scanner.nextInt();

            // Evaluacion de la Temperatura
            int temperaturaMinima, temperaturaMaxima, temperaturaPeligrosa;

            switch (momentoDia) {
                case "manana":
                    temperaturaMinima = temperaturaMananaMuyBuena;
                    temperaturaMaxima = temperaturaMananaNormalMax;
                    temperaturaPeligrosa = temperaturaMananaPeligrosa;
                    break;
                case "tarde":
                    temperaturaMinima = temperaturaTardeMuyBuena;
                    temperaturaMaxima = temperaturaTardeNormalMax;
                    temperaturaPeligrosa = temperaturaTardePeligrosa;
                    break;
                case "noche":
                    temperaturaMinima = temperaturaNocheMuyBuena;
                    temperaturaMaxima = temperaturaNocheNormalMax;
                    temperaturaPeligrosa = temperaturaNochePeligrosa;
                    break;
                default:
                    throw new IllegalArgumentException("Momento del dia no valido.");
            }

            String evaluacion;
            if (temperaturaActual < temperaturaMinima) {
                evaluacion = "Muy Buena";
            } else if (temperaturaActual >= temperaturaMinima && temperaturaActual <= temperaturaMaxima) {
                evaluacion = "Normal";
            } else {
                evaluacion = "Peligrosa";
            }

            // Resultado de la Evaluacion
            System.out.println("La temperatura es: " + evaluacion + " para el momento del dia " + momentoDia);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}